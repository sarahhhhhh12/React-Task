
import { useEffect } from 'react'
import { useLeads, filteredLeads } from '../store/leads'
import { Table, THead, TBody, TR, TH, TD } from '../components/ui/table'
import { Badge } from '../components/ui/badge'
import { Avatar } from '../components/ui/avatar'
import { Button } from '../components/ui/button'
import { Checkbox } from '../components/ui/checkbox'

const tagColors: Record<string, string> = {
  'Team': 'border-purple-300 text-purple-700 bg-purple-50',
  'GITEX DUBAI': 'border-emerald-300 text-emerald-700 bg-emerald-50',
  'Summit': 'border-amber-300 text-amber-700 bg-amber-50',
  'No tags': 'border-gray-300 text-gray-600 bg-gray-50',
}

export function Dashboard() {
  const { fetch, loading, error, tag, setTag } = useLeads()
  const items = filteredLeads()

  useEffect(() => { fetch() }, [fetch])

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="text-lg font-semibold">Leads</div>
        <div className="flex items-center gap-2">
          <select
            className="h-10 rounded-xl border border-input bg-white px-3 text-sm"
            value={tag}
            onChange={(e)=>setTag(e.target.value as any)}
          >
            <option value="all">All tags</option>
            <option value="Team">Team</option>
            <option value="GITEX DUBAI">GITEX DUBAI</option>
            <option value="Summit">Summit</option>
            <option value="No tags">No tags</option>
          </select>
          <Button>Export</Button>
        </div>
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <Table className="min-w-[720px]">
            <THead>
              <TR>
                <TH><Checkbox aria-label="Select all" /></TH>
                <TH>Lead</TH>
                <TH>Tags</TH>
                <TH>Connected with</TH>
                <TH>Date</TH>
                <TH className="text-right">Export</TH>
              </TR>
            </THead>
            <TBody>
              {loading && (
                <TR><TD colSpan={6}><div className="p-6 text-center text-sm">Loading...</div></TD></TR>
              )}
              {error && (
                <TR><TD colSpan={6}><div className="p-6 text-center text-sm text-red-600">{error}</div></TD></TR>
              )}
              {!loading && !error && items.map(l => (
                <TR key={l.id}>
                  <TD><Checkbox aria-label={`Select ${l.name}`} /></TD>
                  <TD>
                    <div className="flex items-center gap-3">
                      <Avatar src={l.avatar} alt={l.name} />
                      <div>
                        <div className="font-medium">{l.name}</div>
                        <div className="text-xs text-gray-500">{l.email}</div>
                      </div>
                    </div>
                  </TD>
                  <TD>
                    <Badge className={tagColors[l.tag || 'No tags'] || ''}>{l.tag}</Badge>
                  </TD>
                  <TD>
                    <div className="flex items-center gap-2">
                      <Avatar className="h-6 w-6" src={`https://i.pravatar.cc/100?img=${(l.id%20)+3}`} />
                      <span className="text-sm">{l.connectedWith}</span>
                    </div>
                  </TD>
                  <TD>{new Date(l.date || '').toLocaleDateString()}</TD>
                  <TD className="text-right">
                    <button className="rounded-xl border px-2 py-1 text-xs">Export</button>
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        </div>
      </div>
    </div>
  )
}
