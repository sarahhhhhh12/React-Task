
import { create } from 'zustand'

export type Lead = {
  id: number
  name: string
  email: string
  company: string
  city: string
  tag?: string
  connectedWith?: string
  avatar?: string
  date?: string
}

type State = {
  leads: Lead[]
  query: string
  tag: string | 'all'
  loading: boolean
  error?: string
  fetch: () => Promise<void>
  setQuery: (q: string) => void
  setTag: (t: string | 'all') => void
}

export const useLeads = create<State>((set, get) => ({
  leads: [],
  query: '',
  tag: 'all',
  loading: false,
  async fetch() {
    try {
      set({ loading: true, error: undefined })
      const res = await fetch('https://jsonplaceholder.typicode.com/users')
      const data = await res.json()
      const tags = ['Team', 'GITEX DUBAI', 'Summit', 'No tags']
      const avatars = [
        'https://i.pravatar.cc/150?img=1',
        'https://i.pravatar.cc/150?img=5',
        'https://i.pravatar.cc/150?img=7',
        'https://i.pravatar.cc/150?img=8',
        'https://i.pravatar.cc/150?img=10',
      ]
      const today = new Date()
      const leads = data.map((u: any, idx: number) => ({
        id: u.id,
        name: u.name,
        email: u.email,
        company: u.company?.name || '',
        city: u.address?.city || '',
        tag: tags[idx % tags.length],
        connectedWith: ['Efehan Coskun', 'Hande Yilmaz', 'Demir Vural'][idx % 3],
        avatar: avatars[idx % avatars.length],
        date: new Date(today.getTime() - idx * 86400000).toISOString(),
      }))
      set({ leads, loading: false })
    } catch (e: any) {
      set({ error: e?.message || 'Failed to fetch', loading: false })
    }
  },
  setQuery(q) { set({ query: q }) },
  setTag(t) { set({ tag: t }) },
}))

export const filteredLeads = () => {
  const { leads, query, tag } = useLeads.getState()
  const q = query.toLowerCase()
  return leads.filter(l =>
    (tag === 'all' || l.tag === tag) &&
    (l.name.toLowerCase().includes(q) ||
      l.email.toLowerCase().includes(q) ||
      l.company.toLowerCase().includes(q) ||
      l.city.toLowerCase().includes(q))
  )
}
