
import * as React from 'react'
import * as AvatarPrimitive from '@radix-ui/react-avatar'
import { cn } from '../../lib/utils'

export function Avatar({ src, alt, className }: { src?: string; alt?: string; className?: string }) {
  return (
    <AvatarPrimitive.Root className={cn('inline-flex h-8 w-8 overflow-hidden rounded-full', className)}>
      <AvatarPrimitive.Image src={src} alt={alt} className="h-full w-full object-cover" />
      <AvatarPrimitive.Fallback className="flex h-full w-full items-center justify-center bg-secondary">
        <span className="text-xs">?</span>
      </AvatarPrimitive.Fallback>
    </AvatarPrimitive.Root>
  )
}
