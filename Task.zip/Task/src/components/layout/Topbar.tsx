
import { Search, Bell } from 'lucide-react'
import { Input } from '../ui/input'
import { useLeads } from '../../store/leads'

export function Topbar() {
  const { query, setQuery } = useLeads()
  return (
    <header className="sticky top-0 z-10 flex items-center justify-between gap-3 border-b bg-white px-4 py-3">
      <div className="flex items-center gap-2">
        <div className="md:hidden font-semibold">Synergy</div>
      </div>
      <div className="relative max-w-md w-full">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400"/>
        <Input
          value={query}
          onChange={(e)=>setQuery(e.target.value)}
          placeholder="Search leads, email, company, city..."
          className="pl-9"
        />
      </div>
      <div className="flex items-center gap-3">
        <Bell className="h-5 w-5" />
        <img className="h-8 w-8 rounded-full" src="https://i.pravatar.cc/100?img=12" />
      </div>
    </header>
  )
}
