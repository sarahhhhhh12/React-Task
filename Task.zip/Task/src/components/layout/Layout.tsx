
import { Sidebar } from './Sidebar'
import { Topbar } from './Topbar'

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-muted text-foreground">
      <div className="flex">
        <Sidebar />
        <main className="flex-1">
          <Topbar />
          <div className="p-4 md:p-6">{children}</div>
        </main>
      </div>
    </div>
  )
}
