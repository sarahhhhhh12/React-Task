
import { cn } from '../../lib/utils'
import { Users, Settings, HelpCircle, Tags, Box, Layers, FlaskConical, PanelsTopLeft } from 'lucide-react'

const NavItem = ({ icon: Icon, label, active=false }: any) => (
  <div className={cn('flex items-center gap-3 rounded-xl px-3 py-2 text-sm cursor-pointer',
    active ? 'bg-secondary font-medium' : 'hover:bg-secondary')}>
    <Icon className="h-4 w-4" />
    <span>{label}</span>
  </div>
)

export function Sidebar() {
  return (
    <aside className="hidden md:flex w-64 flex-col gap-2 border-r bg-white p-4">
      <div className="mb-2 flex items-center gap-2 text-lg font-semibold">
        <PanelsTopLeft className="h-5 w-5"/> Synergy
      </div>
      <div className="text-xs uppercase text-gray-500 px-1">Team Management</div>
      <NavItem icon={Users} label="Members" />
      <NavItem icon={Layers} label="Departments" />
      <NavItem icon={FlaskConical} label="Bulk Adjustments" />
      <div className="text-xs uppercase text-gray-500 px-1 mt-3">Leads Management</div>
      <NavItem icon={Users} label="Leads" active />
      <NavItem icon={Tags} label="Tags" />
      <div className="text-xs uppercase text-gray-500 px-1 mt-3">Brand & Products</div>
      <NavItem icon={Box} label="Customization" />
      <NavItem icon={Box} label="Products" />
      <div className="text-xs uppercase text-gray-500 px-1 mt-3">Configuration</div>
      <NavItem icon={Settings} label="Integrations" />
      <NavItem icon={Settings} label="Settings" />
      <div className="text-xs uppercase text-gray-500 px-1 mt-3">Support</div>
      <NavItem icon={HelpCircle} label="FAQs" />
    </aside>
  )
}
