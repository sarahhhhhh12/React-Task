
/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        border: "hsl(214, 12%, 89%)",
        input: "hsl(214, 12%, 89%)",
        ring: "hsl(215, 20%, 65%)",
        background: "hsl(0,0%,100%)",
        foreground: "hsl(215, 20%, 15%)",
        muted: "hsl(214, 12%, 95%)",
        primary: {
          DEFAULT: "hsl(263, 90%, 51%)",
          foreground: "white"
        },
        secondary: {
          DEFAULT: "hsl(214, 12%, 96%)",
          foreground: "hsl(215, 20%, 15%)"
        },
      },
      borderRadius: {
        '2xl': '1rem'
      }
    },
  },
  plugins: [],
}
