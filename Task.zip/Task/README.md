
# Tap Task — React + shadcn/ui style + Zustand

A small, fully responsive dashboard that mirrors the provided Figma layout.  
- **UI**: TailwindCSS with shadcn-style components (no generator needed).  
- **State**: Zustand.  
- **Data**: Public API — `https://jsonplaceholder.typicode.com/users` (mocked avatars/tags).

## Quick Start

```bash
npm i
npm run dev
```

Open the printed local URL.

## Build
```bash
npm run build
npm run preview
```

## Structure
- `src/components/ui/*` – Minimal shadcn-like primitives (Button, Input, Table, Badge, Avatar, Checkbox).
- `src/components/layout/*` – Sidebar + Topbar + Layout.
- `src/pages/Dashboard.tsx` – Leads page with search + tag filter + export button.
- `src/store/leads.ts` – Zustand store fetching public users and applying filters.

## Notes
- The layout and spacing follow the shared Figma: left sidebar, top app bar, and a leads table with avatars, tags, connector, date, and export column.
- The app is responsive. On small screens the sidebar collapses (hidden) and the table is horizontally scrollable.

## Email Submission
Zip the project and send to: **mohamed.ashraf@gettap.co**  
Subject: **Task Assignment: Build React Web App (Figma + shadcn/ui + Zustand)**

## Optional
- Replace the API with any other public endpoint.
- Extend filters (city/company), add pagination, or selection actions.
